
package customer_billing;

public interface Discountable {
        int applyDiscount(int price, int discountRate);
    }



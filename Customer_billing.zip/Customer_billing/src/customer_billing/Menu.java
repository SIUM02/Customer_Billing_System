package customer_billing;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Menu extends JFrame {

    public Menu() {

        setTitle("Inventory List");
        setSize(300, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[] columnNames = {"Sl No.", "Name", "Price"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);

        try {
            BufferedReader reader = new BufferedReader(new FileReader("inventory.txt"));
            String line;
            int serialNo = 1;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                double price = Double.parseDouble(parts[1]);

                Object[] row = {serialNo++, name, price};
                tableModel.addRow(row);
            }
            reader.close();
        } catch (IOException e) {
           
             JOptionPane.showMessageDialog(this, "There is no item in menu!");
        }

        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);
    }
}


package customer_billing;

import java.util.ArrayList;


public class Global {
    public static ArrayList<Inventory> inventorylist =new ArrayList<>();
    public static ArrayList<Inventory> invoice =new ArrayList<>();
    public static int sum;
    public static int vat;
  

    
    
     
    
}

package customer_billing;

import javax.swing.JOptionPane;

public class Billing_items extends javax.swing.JFrame{

    public Billing_items() {

        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        inv = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        bill = new javax.swing.JButton();
        Cus = new javax.swing.JButton();
        add = new javax.swing.JButton();
        update = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        lab = new javax.swing.JLabel();
        q1 = new javax.swing.JTextField();
        q2 = new javax.swing.JTextField();
        f2 = new javax.swing.JTextField();
        q3 = new javax.swing.JTextField();
        f3 = new javax.swing.JTextField();
        q4 = new javax.swing.JTextField();
        f4 = new javax.swing.JTextField();
        q5 = new javax.swing.JTextField();
        f5 = new javax.swing.JTextField();
        q6 = new javax.swing.JTextField();
        f6 = new javax.swing.JTextField();
        q7 = new javax.swing.JTextField();
        f7 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        f1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Billing");
        setAlwaysOnTop(true);
        setLocation(new java.awt.Point(260, 150));

        jLabel5.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Update Inventory");
        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        inv.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        inv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/rsz_1download-1.jpg"))); // NOI18N
        inv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                invMousePressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Invoice");

        bill.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        bill.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Bill.jpg"))); // NOI18N
        bill.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                billMousePressed(evt);
            }
        });

        Cus.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        Cus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Customer-info.jpg"))); // NOI18N
        Cus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CusMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                CusMousePressed(evt);
            }
        });
        Cus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CusActionPerformed(evt);
            }
        });

        add.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/download.jpg"))); // NOI18N
        add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                addMousePressed(evt);
            }
        });
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        update.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Add_inventory.jpg"))); // NOI18N
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                updateMousePressed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Home.png"))); // NOI18N
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton5MousePressed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Billing Items");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Home");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Customer Info");
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Add Item");
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/rsz_2images.jpg"))); // NOI18N
        jButton7.setText("MENU");
        jButton7.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton7MousePressed(evt);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Quantity");
        jLabel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lab.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        lab.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lab.setText("Item's SL no.");
        lab.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        q1.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        q1.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        q2.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        q2.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        f2.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        f2.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        q3.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        q3.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        f3.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        f3.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        q4.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        q4.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        f4.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        f4.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        q5.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        q5.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        f5.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        f5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f5ActionPerformed(evt);
            }
        });

        q6.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        q6.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        f6.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        f6.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        q7.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        q7.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        f7.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        f7.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jButton8.setFont(new java.awt.Font("InaiMathi", 1, 24)); // NOI18N
        jButton8.setForeground(new java.awt.Color(0, 255, 0));
        jButton8.setText("Submit");
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton8MousePressed(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jTextArea1.setBackground(new java.awt.Color(242, 242, 242));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Helvetica Neue", 0, 17)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("**Additional 5% vat will be added\n\n**You can refund your unused product \nwithin 3 working days.\n\n**10% Discount over TK.2000 Shopping\n\n--Happy Shopping--");
        jTextArea1.setToolTipText("");
        jTextArea1.setBorder(null);
        jScrollPane1.setViewportView(jTextArea1);

        f1.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        f1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lab, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(228, 228, 228))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(38, 38, 38)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(bill, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(42, 42, 42)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Cus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(inv)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(98, 98, 98)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(f7, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(55, 55, 55)
                                                .addComponent(q7, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(f6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(55, 55, 55)
                                                    .addComponent(q6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(f5, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(55, 55, 55)
                                                    .addComponent(q5, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(f4, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(55, 55, 55)
                                                    .addComponent(q4, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(f1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(f3, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(f2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGap(55, 55, 55)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(q3, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(q1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(279, 279, 279)
                                        .addComponent(q2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(253, 253, 253))))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(356, 356, 356))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(bill)
                            .addComponent(Cus)
                            .addComponent(add)
                            .addComponent(update)
                            .addComponent(jButton5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(inv)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lab, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(f1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(q2, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                            .addComponent(f2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(f3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(f4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(f5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(f6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(f7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void billMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_billMousePressed
        new Billing_items().setVisible(true);
        dispose();
    }//GEN-LAST:event_billMousePressed

    private void CusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CusMouseClicked

        new Customer_info().setVisible(true);

        dispose();
    }//GEN-LAST:event_CusMouseClicked

    private void CusMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CusMousePressed
        new Search().setVisible(true);

        dispose();
    }//GEN-LAST:event_CusMousePressed

    private void CusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CusActionPerformed

    }//GEN-LAST:event_CusActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed

    }//GEN-LAST:event_addActionPerformed

    private void addMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addMousePressed
        new Add_items().setVisible(true);
        dispose();
    }//GEN-LAST:event_addMousePressed

    private void updateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMousePressed
        new Update_items().setVisible(true);
        dispose();
    }//GEN-LAST:event_updateMousePressed

    private void invMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_invMousePressed
        new Invoice("Nothing to show !!").setVisible(true);
        dispose();
    }//GEN-LAST:event_invMousePressed

    private void jButton5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MousePressed
        new Home().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton5MousePressed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MousePressed
        new Menu().setVisible(true);
    }//GEN-LAST:event_jButton7MousePressed

    private void jButton8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MousePressed

        Global.invoice.clear();

        int x, y = 0;
        if ("".equals(f1.getText())) {

        } else {
            x = Integer.parseInt(f1.getText()) - 1;
            y = Integer.parseInt(q1.getText());
            if (x >= 0 && x < Global.inventorylist.size()) {

                Global.invoice.add(new Inventory(Global.inventorylist.get(x).getName(), Global.inventorylist.get(x).getPrice(), y));

            } else {
                JOptionPane.showMessageDialog(this, "Some serial number is not valid !!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        if ("".equals(f2.getText())) {

        } else {
            x = Integer.parseInt(f2.getText()) - 1;
            y = Integer.parseInt(q2.getText());
            if (x >= 0 && x < Global.inventorylist.size()) {
                Global.invoice.add(new Inventory(Global.inventorylist.get(x).getName(), Global.inventorylist.get(x).getPrice(), y));
            }
        }

        if ("".equals(f3.getText())) {

        } else {
            x = Integer.parseInt(f3.getText()) - 1;
            y = Integer.parseInt(q3.getText());
            if (x >= 0 && x < Global.inventorylist.size()) {
                Global.invoice.add(new Inventory(Global.inventorylist.get(x).getName(), Global.inventorylist.get(x).getPrice(), y));
            }
        }

        if ("".equals(f4.getText())) {

        } else {
            x = Integer.parseInt(f4.getText()) - 1;
            y = Integer.parseInt(q4.getText());
            if (x >= 0 && x < Global.inventorylist.size()) {
                Global.invoice.add(new Inventory(Global.inventorylist.get(x).getName(), Global.inventorylist.get(x).getPrice(), y));
            }
        }

        if ("".equals(f5.getText())) {

        } else {
            x = Integer.parseInt(f5.getText()) - 1;
            y = Integer.parseInt(q5.getText());
            if (x >= 0 && x < Global.inventorylist.size()) {
                Global.invoice.add(new Inventory(Global.inventorylist.get(x).getName(), Global.inventorylist.get(x).getPrice(), y));
            }
        }

        if ("".equals(f6.getText())) {

        } else {
            x = Integer.parseInt(f6.getText()) - 1;
            y = Integer.parseInt(q6.getText());
            if (x >= 0 && x < Global.inventorylist.size()) {
                Global.invoice.add(new Inventory(Global.inventorylist.get(x).getName(), Global.inventorylist.get(x).getPrice(), y));
            }
        }

        if ("".equals(f7.getText())) {

        } else {
            x = Integer.parseInt(f7.getText()) - 1;
            y = Integer.parseInt(q7.getText());
            if (x >= 0 && x < Global.inventorylist.size()) {
                Global.invoice.add(new Inventory(Global.inventorylist.get(x).getName(), Global.inventorylist.get(x).getPrice(), y));
            }
        }

        int sum = 0;
        for (Inventory i : Global.invoice) {
            if (i == null || i.getQuantity() == 0) {
                continue;
            }
            System.out.println(i.getName() + " " + i.getPrice() + " " + i.getQuantity());
            sum += i.getQuantity() * i.getPrice();
        }
       
        
        Global.sum = sum ;
        Global.vat= (int) (sum*0.05);
        

        new Customer_info().setVisible(true);

        dispose();


    }//GEN-LAST:event_jButton8MousePressed

    private void f5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_f5ActionPerformed

    private void f1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_f1ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

   
    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Billing_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Billing_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Billing_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Billing_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                new Billing_items().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cus;
    private javax.swing.JButton add;
    private javax.swing.JButton bill;
    private javax.swing.JTextField f1;
    private javax.swing.JTextField f2;
    private javax.swing.JTextField f3;
    private javax.swing.JTextField f4;
    private javax.swing.JTextField f5;
    private javax.swing.JTextField f6;
    private javax.swing.JTextField f7;
    private javax.swing.JButton inv;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lab;
    private javax.swing.JTextField q1;
    private javax.swing.JTextField q2;
    private javax.swing.JTextField q3;
    private javax.swing.JTextField q4;
    private javax.swing.JTextField q5;
    private javax.swing.JTextField q6;
    private javax.swing.JTextField q7;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables

 

}
